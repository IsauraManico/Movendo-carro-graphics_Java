
package CarroIsa;

import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author isaura
 */
public class Desenhar extends JPanel implements Runnable
{
    Carro carro = new Carro(100,600,300,100,130,700,50,100,300,700,50,100);
    
    //Carro carro1 = new Carro( 1300, 700, 50, 100);
   // Carro carro2 = new Carro( 160, 700, 50, 100);
    
    Thread thread = new Thread(this);

    public Desenhar()
    {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);
        frame.setSize(1000,1000);
        frame.setVisible(true);
        
        thread.start();
    }
    @Override
    public void run() 
    {
       
        while( true)
        {   
             System.out.println("Sempre");
        
                atualizar();
                dormir();
                repaint();
        }
    }
    
    public void dormir()
    {
        try
        {
            Thread.sleep(10);
        } catch (InterruptedException ex) 
        {
            Logger.getLogger(Desenhar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void atualizar()
    {
        if(carro.getPosx()>= getWidth()-carro.getLargura())
        {
           
            carro.setDx(carro.getDx()*(-1));
            
            
        }
        else if(carro.getPosx()<=0)
        {
              carro.setDx( carro.getDx()*(-1));
        }
         carro.atualizar();
       
        
    }
    
    public void paint(Graphics g)
    {
        super.paint(g);
        
        g.setColor(Color.blue);
        g.fillRect(carro.getPosx(), carro.getPosy(), carro.getLargura(), carro.getAltura());
        g.setColor(Color.yellow);
        g.fillOval(carro.getPosx1(), carro.getPosy1(), carro.getLargura1(), carro.getAltura1());
        g.fillOval( carro.getPosx2(), carro.getPosy2(), carro.getLargura2(), carro.getAltura2());
    }
    
    
    
}
