
package CarroIsa;

/**
 *
 * @author isaura
 */
public class Carro
{
    private int posx,posy,largura,altura;
    private int posx1,posy1,largura1,altura1;
    private int posx2,posy2,largura2,altura2;
    
    int dx= 3;
    int dy = 3;;

    public Carro(int posx, int posy, int largura, int altura, int posx1, int posy1, int largura1, int altura1, int posx2, int posy2, int largura2, int altura2) {
        this.posx = posx;
        this.posy = posy;
        this.largura = largura;
        this.altura = altura;
        this.posx1 = posx1;
        this.posy1 = posy1;
        this.largura1 = largura1;
        this.altura1 = altura1;
        this.posx2 = posx2;
        this.posy2 = posy2;
        this.largura2 = largura2;
        this.altura2 = altura2;
    }
    
    
   

    public int getPosx() {
        return posx;
    }

    public void setPosx(int posx) {
        this.posx = posx;
    }

    public int getPosy() {
        return posy;
    }

    public void setPosy(int posy) {
        this.posy = posy;
    }

    public int getLargura() {
        return largura;
    }

    public void setLargura(int largura) {
        this.largura = largura;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getDx() {
        return dx;
    }

    public void setDx(int dx) {
        this.dx = dx;
    }

    public int getDy() {
        return dy;
    }

    public void setDy(int dy) {
        this.dy = dy;
    }

    public int getPosx1() {
        return posx1;
    }

    public void setPosx1(int posx1) {
        this.posx1 = posx1;
    }

    public int getPosy1() {
        return posy1;
    }

    public void setPosy1(int posy1) {
        this.posy1 = posy1;
    }

    public int getLargura1() {
        return largura1;
    }

    public void setLargura1(int largura1) {
        this.largura1 = largura1;
    }

    public int getAltura1() {
        return altura1;
    }

    public void setAltura1(int altura1) {
        this.altura1 = altura1;
    }

    public int getPosx2() {
        return posx2;
    }

    public void setPosx2(int posx2) {
        this.posx2 = posx2;
    }

    public int getPosy2() {
        return posy2;
    }

    public void setPosy2(int posy2) {
        this.posy2 = posy2;
    }

    public int getLargura2() {
        return largura2;
    }

    public void setLargura2(int largura2) {
        this.largura2 = largura2;
    }

    public int getAltura2() {
        return altura2;
    }

    public void setAltura2(int altura2) {
        this.altura2 = altura2;
    }
    
    
    
    
    public void atualizar()
    {
        this.posx+=dx;
        this.posx1+=dx;
        this.posx2+=dx;
       // this.posy+= dy;
    }
    
    
    
}
