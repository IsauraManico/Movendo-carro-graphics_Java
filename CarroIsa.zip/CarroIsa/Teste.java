
package CarroIsa;

/**
 *
 * @author isaura
 */
public class Teste 
{
    public static void main(String[] args)
    {
        new Desenhar();
    }
}
